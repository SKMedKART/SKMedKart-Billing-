# SKMedKART – Sri Krishna Medicals

Android starter project for a pharmacy billing and customer reminder app.

## Included
- New bill entry
- Customer records
- Medicine stock records
- Sales history
- Local reminder notification (tomorrow)
- Offline SQLite database

## Build
Open the project in Android Studio and run the `app` configuration. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included under `.github/workflows/android.yml` to build the debug APK automatically after upload.
