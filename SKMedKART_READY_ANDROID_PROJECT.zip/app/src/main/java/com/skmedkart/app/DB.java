package com.skmedkart.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {
    public DB(Context context) { super(context, "skmedkart.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,notes TEXT)");
        db.execSQL("CREATE TABLE medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,price REAL NOT NULL,stock INTEGER NOT NULL,expiry TEXT)");
        db.execSQL("CREATE TABLE bills(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT,phone TEXT,total REAL NOT NULL,created TEXT NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    public long addCustomer(String name,String phone,String notes){ ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("notes",notes);return getWritableDatabase().insert("customers",null,v); }
    public long addMedicine(String name,double price,int stock,String expiry){ ContentValues v=new ContentValues();v.put("name",name);v.put("price",price);v.put("stock",stock);v.put("expiry",expiry);return getWritableDatabase().insert("medicines",null,v); }
    public long addBill(String customer,String phone,double total,String created){ ContentValues v=new ContentValues();v.put("customer",customer);v.put("phone",phone);v.put("total",total);v.put("created",created);return getWritableDatabase().insert("bills",null,v); }
    public Cursor customers(){ return getReadableDatabase().rawQuery("SELECT id,name,phone,notes FROM customers ORDER BY id DESC",null); }
    public Cursor medicines(){ return getReadableDatabase().rawQuery("SELECT id,name,price,stock,expiry FROM medicines ORDER BY id DESC",null); }
    public Cursor bills(){ return getReadableDatabase().rawQuery("SELECT id,customer,phone,total,created FROM bills ORDER BY id DESC",null); }
}
