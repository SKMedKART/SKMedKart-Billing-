package com.skmedkart.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private DB db; private LinearLayout box; private final int PAD=24;
    @Override public void onCreate(Bundle state){ super.onCreate(state); db=new DB(this); requestNotificationPermission(); home(); }
    private TextView text(String s,int size){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(PAD,12,PAD,12);return t; }
    private Button button(String s){ Button b=new Button(this);b.setText(s);return b; }
    private EditText input(String hint){ EditText e=new EditText(this);e.setHint(hint);e.setPadding(PAD,12,PAD,12);box.addView(e);return e; }
    private void page(String title){ box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(12,12,12,12);ScrollView sc=new ScrollView(this);sc.addView(box);setContentView(sc);TextView h=text(title,25);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);box.addView(h); }
    private void home(){ page("🏪 Sri Krishna Medicals");box.addView(text("SKMedKART • Pharmacy Billing & Reminder",17));
        Button b=button("🧾 New Bill");box.addView(b);b.setOnClickListener(v->bill());
        b=button("👤 Customers & Reminders");box.addView(b);b.setOnClickListener(v->customers());
        b=button("💊 Medicine Stock");box.addView(b);b.setOnClickListener(v->medicines());
        b=button("📊 Sales History");box.addView(b);b.setOnClickListener(v->sales());
    }
    private void bill(){ page("🧾 New Bill");EditText c=input("Customer name");EditText p=input("Mobile number");p.setInputType(2);input("Medicine / items");EditText total=input("Total amount ₹");total.setInputType(2|8192);
        Button save=button("SAVE BILL");box.addView(save);Button back=button("← Home");box.addView(back);back.setOnClickListener(v->home());
        save.setOnClickListener(v->{try{double x=Double.parseDouble(total.getText().toString());String d=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());db.addBill(c.getText().toString(),p.getText().toString(),x,d);Toast.makeText(this,"Bill saved ₹"+x,Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Enter a valid total",Toast.LENGTH_SHORT).show();}});
    }
    private void customers(){ page("👤 Customers & Reminders");EditText n=input("Customer name");EditText p=input("Mobile number");p.setInputType(2);EditText notes=input("Reminder note");Button add=button("ADD CUSTOMER");box.addView(add);add.setOnClickListener(v->{if(n.getText().toString().trim().isEmpty()){Toast.makeText(this,"Enter customer name",Toast.LENGTH_SHORT).show();return;}db.addCustomer(n.getText().toString(),p.getText().toString(),notes.getText().toString());customers();});
        Cursor cur=db.customers();while(cur.moveToNext()){String name=cur.getString(1);box.addView(text("• "+name+"  "+cur.getString(2)+"\n  "+cur.getString(3),16));Button r=button("🔔 Remind tomorrow — "+name);box.addView(r);r.setOnClickListener(v->setReminder(name));}cur.close();Button back=button("← Home");box.addView(back);back.setOnClickListener(v->home()); }
    private void setReminder(String customer){ AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));return;}Intent i=new Intent(this,ReminderReceiver.class);i.putExtra("customer",customer);i.putExtra("message","Medicine refill reminder");PendingIntent pi=PendingIntent.getBroadcast(this,(int)(System.currentTimeMillis()%100000),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+86400000L,pi);Toast.makeText(this,"Reminder set for tomorrow",Toast.LENGTH_SHORT).show(); }
    private void medicines(){ page("💊 Medicine Stock");EditText n=input("Medicine name");EditText price=input("Selling price ₹");price.setInputType(2|8192);EditText stock=input("Stock quantity");stock.setInputType(2);input("Expiry (MM/YYYY)");EditText exp=(EditText)box.getChildAt(box.getChildCount()-1);Button add=button("ADD MEDICINE");box.addView(add);add.setOnClickListener(v->{try{db.addMedicine(n.getText().toString(),Double.parseDouble(price.getText().toString()),Integer.parseInt(stock.getText().toString()),exp.getText().toString());medicines();}catch(Exception e){Toast.makeText(this,"Check medicine details",Toast.LENGTH_SHORT).show();}});Cursor cur=db.medicines();while(cur.moveToNext())box.addView(text("💊 "+cur.getString(1)+"  ₹"+cur.getDouble(2)+"\nStock: "+cur.getInt(3)+"   Expiry: "+cur.getString(4),16));cur.close();Button back=button("← Home");box.addView(back);back.setOnClickListener(v->home()); }
    private void sales(){ page("📊 Sales History");Cursor cur=db.bills();double sum=0;while(cur.moveToNext()){sum+=cur.getDouble(3);box.addView(text("🧾 "+cur.getString(1)+"  ₹"+cur.getDouble(3)+"\n"+cur.getString(4),16));}cur.close();box.addView(text("TOTAL SALES: ₹"+sum,21));Button back=button("← Home");box.addView(back);back.setOnClickListener(v->home()); }
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);}
}
